//
//  main.m
//  RNHybirdiOS
//
//  Created by jph on 26/06/2018.
//  Copyright © 2018 devio. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
