import {NativeModules} from 'react-native';

export default NativeModules.JSBridgeModule;