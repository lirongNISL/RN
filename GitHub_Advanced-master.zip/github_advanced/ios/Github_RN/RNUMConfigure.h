

#import <Foundation/Foundation.h>
#import <UMCommon/UMCommon.h>

@interface RNUMConfigure : NSObject

+ (void)initWithAppkey:(NSString *)appkey channel:(NSString *)channel;

@end
